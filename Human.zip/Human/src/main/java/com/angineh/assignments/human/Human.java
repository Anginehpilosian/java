package com.angineh.assignments.human;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Human {

	@RequestMapping("/")
	public String human(@RequestParam(value="name" , required=false) String name, @RequestParam(value="lname" , required=false) String lname) {
		if(name!= null) {
			return "Hello " + name + lname ;
		}
		return "<h1>Hello Human</h1> <p>Welcome to SpringBoot!</p>" ;
	}
	//....http://localhost:8080/?name=Angineh&lname=Pilosian
	

}
