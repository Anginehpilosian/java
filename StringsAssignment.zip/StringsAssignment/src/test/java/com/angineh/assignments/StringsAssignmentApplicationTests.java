package com.angineh.assignments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringsAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
